#include "Individual.h"

Individual::Individual(std::vector<int>& genotype, CLFLnetEvaluator * evaluator) 
{
	this->evaluator = evaluator;
	this->genotype = std::move(genotype);
	this->fitness = evaluator->dEvaluate(&this->genotype);
}

Individual::Individual() : evaluator(NULL)
{
	this->fitness = 0.0;
}

Individual::Individual(const Individual & other)

{
	genotype = other.genotype;
	evaluator = other.evaluator;
	fitness = other.fitness;
}

Individual::Individual(Individual && other)
{
	genotype = std::move(other.genotype);
	evaluator = other.evaluator;
	fitness = other.fitness;
}


double Individual::getFitness()
{
	return fitness;
}

void Individual::mutate(double probability)
{
	for (int i = 0; i < genotype.size(); i++) {
		if (dRand() < probability) {
			genotype[i] = lRand(evaluator->iGetNumberOfValues(i));
		}
	}
	fitness = evaluator->dEvaluate(&genotype);

}

std::vector<Individual*> Individual::cross(Individual * with)
{
	int slicePoint = lRand(genotype.size() - 1) + 1;

	std::vector<int> genotype1;
	std::vector<int> genotype2;

	for (int i = 0; i < genotype.size(); i++) {
		genotype1.push_back(i < slicePoint ? this->genotype[i] : with->genotype[i]);
		genotype2.push_back(i < slicePoint ?  with->genotype[i] : this->genotype[i]);
	}
	std::vector<Individual*> result = {
		new Individual(genotype1, evaluator),
		new Individual(genotype2, evaluator),
	};
	return std::move(result);

}

Individual & Individual::operator=(Individual & other)
{
	genotype = other.genotype;
	evaluator = other.evaluator;
	fitness = other.fitness;

	return *this;


}

Individual & Individual::operator=(Individual && other)
{
	genotype = std::move(other.genotype);
	evaluator = other.evaluator;
	fitness = other.fitness;

	return *this;
}

