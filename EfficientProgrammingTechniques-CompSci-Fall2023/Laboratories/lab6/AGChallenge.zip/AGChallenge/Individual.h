#pragma once
#include <vector>
#include "Evaluator.h"

class Individual
{
public:
	Individual(std::vector<int>& genotype, CLFLnetEvaluator* evaluator);
	Individual();
	Individual(const Individual &other);
	Individual(Individual &&other);


	double getFitness();
	void mutate(double probability);
	std::vector<Individual*> cross(Individual* with);

	Individual& operator=(Individual &other);
	Individual& operator=(Individual &&other);


private:
	std::vector<int> genotype;
	CLFLnetEvaluator* evaluator;
	double fitness;
};

